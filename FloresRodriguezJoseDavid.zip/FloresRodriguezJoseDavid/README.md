# Estado del proyecto de lo que no se realizó

## Carnage, semaforo y  oficiales de tránsito:

Las ambulancias no se implementaron en inguno de los casos.

## Oficiales de tránsito:

No se implemento la función de que si en determinado sentido no llegan vehículos, el oficial del otro sentido debía dejar pasar los vehículos que estaban esperando.


